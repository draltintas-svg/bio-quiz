# Biologie-Quiz

Diese Version ist für GitHub Pages vorbereitet.

## Hochladen auf GitHub

1. Neues Repository bei GitHub erstellen, z. B. `biologie-quiz`.
2. Die Datei `index.html` in das Repository hochladen.
3. In GitHub öffnen: **Settings → Pages**.
4. Bei **Build and deployment** auswählen:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**
5. Speichern.
6. Danach ist das Quiz über die GitHub-Pages-Adresse erreichbar.

## Wichtig

Die Startdatei muss `index.html` heißen, damit GitHub Pages sie automatisch öffnet.
